test_that("addition works", {
  expect_equal(2+3, add2vars(2, 3))
})
